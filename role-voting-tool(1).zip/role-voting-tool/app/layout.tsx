import './globals.css'; export const metadata={title:'Secret Borda Vote'}; export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
